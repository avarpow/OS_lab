#[allow(non_snake_case)]
#[no_mangle]
fn function_from_Rust(){
    println!("This is a function from Rust.");
}