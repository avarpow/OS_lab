#include <iostream>
int main() {
    std::cout << "Call function from assembly." << std::endl;
    std::cout << "Done." << std::endl;
}